<link href="http://www.thoseappleguys.com/favicon.ico" rel="shortcut icon" type="image/x-icon" /> 
<link href="http://www.thoseappleguys.com/images/buttons/ipod_icon.png" rel="apple-touch-icon" type="image/png" />
<link href="../screen.css" rel="stylesheet" type="text/css" media="all" />