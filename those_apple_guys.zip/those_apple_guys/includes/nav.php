<?php $ran = rand(2, 14); ?>

<!--[if IE]>
	<link rel="stylesheet" type="text/css" href="../all-ie-only.css" />
<![endif]-->
<link rel="stylesheet" type="text/css" href="../shadowbox.css" />
<script type="text/javascript" src="../shadowbox.js"></script>
<script type="text/javascript">
Shadowbox.init({
    language: 'en',
    players:  ['flv']   
});
</script>      
</head>

<body>
<!--[if IE]>
    <div id="ie-warning">

        <p>Your browser is outdated and unsafe. For a richer browsing experience, please consider upgrading to a <a href="http://www.getfirefox.com">better, modern browser</a>.</p>

    </div>
<![endif]-->
<div id="container">

<!--Header Start-->
<div id="header">
<h1><a href="../" title="Those Apple Guys"><em>Those</em> <strong>Apple Guys</strong></a></h1>
<a href="../" title="Those Apple Guys"><img id="header_logo" title="Those Apple Guys" alt="Those Apple Guys" src="../images/logo/tag_text.png" /></a>
<img id="whitehead" title="Mac Guy" alt="Mac Guy" src="../images/backgrounds/white_head.png" />
<img id="quote" title="T.A.G. Quotes" alt="T.A.G. Quotes" src="../images/quotes/<?php echo "$ran"; ?>.png" />
</div>

<!--Navigation Start-->
<div id="navbar">
<ul>
<li id="home" title="Home | Those Apple Guys"><a href="../"></a></li>
<li id="about" title="About Those Apple Guys"><a href="../about"></a></li>
<li id="services" title="Services | Those Apple Guys"><a href="../services"></a></li>
<li id="contact" title="Contact Those Apple Guys"><a href="../contact"></a></li>
</ul>
<h2>Apple Computer Repair and Support North Wales</h2>
</div>
